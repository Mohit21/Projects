#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<ctype.h>
#include<dos.h>
#include<alloc.h>
#include<string.h>
#include<graphics.h>

struct KBC
{
	char ques[80];
	char opt1[20];
	char opt2[20];
	char opt3[20];
	char opt4[20];
	int ans;
	struct KBC *next;
};

typedef struct KBC KBC;
KBC *start=NULL, *p=NULL, *q;

void create(KBC **);
void display(KBC **);

void drawBox(int, int, int, int, int);

void fileMenu();
void playMenu();

void score(int, long int);
void loading();
void millionaire();

void main()
{
	int choice,i,j;
	textbackground(GREEN);
	textcolor(BLUE);
	clrscr();
	drawBox(1,2,80,24,0);
	gotoxy(33,8);
	cprintf("::::WELCOME::::\n\n");
	gotoxy(39,9);
	cprintf(":TO:");
	gotoxy(29,12);
	cprintf("::: WHO WANTS TO BE A :::");
	delay(1000);
	millionaire();

	do
	{
		textbackground(MAGENTA);
		textcolor(WHITE);
		clrscr();
		drawBox(18,6,66,20,0);
		gotoxy(19,13);//mid line
		for(i=0;i<47;i++)
			cprintf("-");
		gotoxy(28,9);
		cprintf("1.Question Database (Admin)");
		gotoxy(28,17);
		cprintf("2.Play Game!        (User)");
		gotoxy(42,21);
		cprintf("(0=Exit)  Enter digit:- ");
		rep:scanf("%d", &choice);
		switch(choice)
		{
			case 0:	break;
			case 1: fileMenu();
				break;
			case 2: playMenu();
				break;
			default:gotoxy(42,21);
		    clreol();
				cprintf("(0=Prev)  Enter again:- ");
		    goto rep;
		}
	}while(choice!=0);

	textbackground(RED);
	textcolor(BLACK);
	clrscr();
	gotoxy(23,12);
	cprintf("THANK YOU FOR PLAYING KBC!");
	delay(1100);
}

void fileMenu()
{
	int choice, i, z=0, check;
	char pass[30], ch='\0', password[]="millionaire";
	do
	{
		textbackground(CYAN);
		textcolor(RED);
		clrscr();
		drawBox(21,10,65,20,0);
		gotoxy(23,12);
		cprintf("Enter admin password:- ");
		while(ch!=13)
		{
			ch=getch();
			if(ch==13)
				break;
			pass[z++]=ch;
			printf("*");
		}
		check=strcmpi(pass,password);
		if(check!=0)
		{
			gotoxy(23,14);
			cprintf("Wrong password! Press Enter to return");
			getch();
			return;
		}
		clrscr();
		drawBox(18,6,66,20,0);
		gotoxy(19,13);//mid line
		for(i=0;i<47;i++)
			cprintf("-");
		gotoxy(28,9);
		cprintf("1.Create KBC Database");
		gotoxy(28,17);
		cprintf("2.Display KBC database");
		gotoxy(42,21);
		cprintf("(0=Prev)  Enter digit:- ");
		rep:scanf("%d",&choice);
		switch(choice)
		{
			case 0: break;
			case 1: create(&p);
				break;
			case 2: display(&p);
				break;
			default:gotoxy(42,21);
				clreol();
				cprintf("(0=Prev)  Enter again:- ");
				goto rep;
		}
	}while(choice!=0);
}

void playMenu()
{
	int i=1,color,check=0,ans;
	long int money=0;
	KBC temp;
	FILE *fptr;
	randomize();
	textbackground(BLUE);
	textcolor(WHITE);
	clrscr();
	loading();
	clrscr();
	if((fptr = fopen("KBCGAME.dat", "r")) == NULL)
	{
		printf("\nFile not found!");
		printf("\nPress any key to return");
		getch();
		return;
	}
	fflush(stdin);
	while(fread(&temp,sizeof(temp),1,fptr))
	{
		color=random(16);
		if(color==0)
			textcolor(2);
		else
		{
			textbackground(color);
			textcolor(color-1);
		}
		clrscr();
		gotoxy(2,2);
		cprintf("QUESTION %d",i++);
		drawBox(20,3,60,9,0);
		gotoxy(22,5);
		cprintf("%s",temp.ques);
		drawBox(10,12,35,16,0);
		gotoxy(12,14);
		cprintf("%s",temp.opt1);
		drawBox(45,12,70,16,0);
		gotoxy(47,14);
		cprintf("%s",temp.opt2);
		drawBox(10,18,35,22,0);
		gotoxy(12,20);
		cprintf("%s",temp.opt3);
		drawBox(45,18,70,22,0);
		gotoxy(47,20);
		cprintf("%s",temp.opt4);
		gotoxy(10,23);
		cprintf("Enter your answer:- ");
		rep:scanf("%d",&ans);
		if(ans<1||ans>4)
		{
			gotoxy(10,23);
			clreol();
			cprintf("Enter again:- ");
			goto rep;
		}
		if(temp.ans==ans)
		{
			check=1;
			money+=1000;
			continue;
		}
		else
		{
			check=0;
			break;
		}
	}
	fclose(fptr);
	score(check,money);
}

void create(KBC **start)
{
	char ques[80],opt1[20],opt2[20],opt3[20],opt4[20],choice;
	int ans;
	FILE *fptr;
	KBC *temp, *r;
	fptr = fopen("KBCGAME.dat", "ab");
	do
	{
		textbackground(WHITE);
		textcolor(BLACK);
		clrscr();
		fflush(stdin);
		cprintf("Enter question(80 chars):- ");
		gets(ques);
		cprintf("Option 1:- ");
		scanf("%s",&opt1);
		cprintf("Option 2:- ");
		scanf("%s",&opt2);
		cprintf("Option 3:- ");
		scanf("%s",&opt3);
		cprintf("Option 4:- ");
		scanf("%s",&opt4);
		cprintf("Correct answer:-");
		repp:scanf("%d",&ans);
		if(ans<1||ans>4)
		{
			clreol();
			cprintf("Enter again:- ");
			goto repp;
		}

		if(*start==NULL)
		{
			temp=(KBC*)malloc(sizeof(KBC));
			strcpy(temp->ques,ques);
			strcpy(temp->opt1,opt1);
			strcpy(temp->opt2,opt2);
			strcpy(temp->opt3,opt3);
			strcpy(temp->opt4,opt4);
			temp->ans=ans;
			temp->next=NULL;
			*start=temp;
			fflush(stdin);
			fwrite(temp, sizeof(KBC), 1, fptr);
		}
		else
		{
			temp=*start;
			while(temp->next!=NULL)
			{
				temp=temp->next;
			}
			r=(KBC*)malloc(sizeof(KBC));
			strcpy(r->ques,ques);
			strcpy(r->opt1,opt1);
			strcpy(r->opt2,opt2);
			strcpy(r->opt3,opt3);
			strcpy(r->opt4,opt4);
			r->ans=ans;
			r->next=NULL;
			temp->next=r;
			fflush(stdin);
			fwrite(r, sizeof(KBC), 1, fptr);
		}
		fflush(stdin);
		cprintf("\n\nDo you want to add more(y/n)? : ");
		choice=getche();getch();
	}while(choice=='y' || choice=='Y');
	fclose(fptr);
}

void display()
{
	int i=1;
	KBC temp;
	FILE *fptr;
	if((fptr = fopen("KBCGAME.dat", "r")) == NULL)
	{
		printf("\nFile not created!");
		printf("\nPress any key to return");
		getch();
		return;
	}

		textbackground(WHITE);
		textcolor(BLACK);
		clrscr();

		fflush(stdin);
		while(fread(&temp,sizeof(temp),1,fptr))
		{
			printf("\nQuestion %d: %s\n", i++, temp.ques);
			printf("\nOpt1: %s\n", temp.opt1);
			printf("\nOpt2: %s\n", temp.opt2);
			printf("\nOpt3: %s\n", temp.opt3);
			printf("\nOpt4: %s\n", temp.opt4);
			printf("\nAns:  %d\n", temp.ans);
			getch();
		}
	fclose(fptr);
}

void drawBox(int x1, int y1, int x2, int y2, int line)
{
	char c1=201,c2=187,c3=204,c4=185,c5=200,c6=188,hr=205,vr=186;
	int i;
	for(i=x1; i<=x2; i++)
	{
		gotoxy(i,y1);
		cprintf("%c",hr);
		if(line==1)
		{
			gotoxy(i, y1+2);
			cprintf("%c",hr);
		}
		gotoxy(i,y2);
		cprintf("%c",hr);
	}
	for(i=y1; i<y2; i++)
	{
		gotoxy(x1,i);
		cprintf("%c",vr);
		gotoxy(x2,i);
		cprintf("%c",vr);
	}
	gotoxy(x1,y1);
	cprintf("%c",c1);
	gotoxy(x2,y1);
	cprintf("%c",c2);
	if(line==1)
	{
		gotoxy(x1,y1+2);
		cprintf("%c",c3);
		gotoxy(x2,y1+2);
		cprintf("%c",c4);
	}
	gotoxy(x1,y2);
	cprintf("%c",c5);
	gotoxy(x2,y2);
	cprintf("%c",c6);
}

void score(int check, long int money)
{
	int gdriver = DETECT, gmode;
	int x,y,i,j;
	char msg[50];
	detectgraph(&gdriver, &gmode);
	initgraph(&gdriver,&gmode,"P:\\TC\\BGI");
	x=getmaxx()/2;
	y=getmaxy()/2;
	for(i=30;i<200;i++)
	{
		delay(20);
		setcolor(i/10);
		arc(x,y,0,360,i-10);
	}
	setbkcolor(YELLOW);
	setcolor(BLUE);
	settextjustify(CENTER_TEXT, CENTER_TEXT);
	settextstyle(TRIPLEX_FONT, HORIZ_DIR, 10);
	cleardevice();
	sprintf(msg,"��KBC��");
	outtextxy(x,y,msg);
	delay(1200);
	cleardevice();
	closegraph();
	textbackground(BLACK);
	textcolor(RED + BLINK);
	clrscr();
	gotoxy(22,12);
	if(check==1)
	{
		cprintf("*-*-*-*-*-*-*CONGRATULATIONS*-*-*-*-*-*-*");
		gotoxy(22,14);
		cprintf("\n         YOU WON %d RUPEES!!!",money);
		getch();
	}
	else
	{
		cprintf("*-*-*-*-*-*-*Better Luck Next Time*-*-*-*-*-*-*");
		gotoxy(22,14);
		cprintf("\n         You Get Only %d Rupees!",money);
		getch();
	}
}

void loading()
{
	int z,y,x,i,j;
	char msg[50],ak[2],pb[]="                   ";
	int gdriver = DETECT, gmode;
	clrscr();
	gotoxy(35,12);
	for(z=1;z<11;z++)
	{
		delay(100);
		pb[(z-1)*2]='�';
		gotoxy(28,12);
		printf("%s %d% Complete.",pb,z*10);
	}
	gotoxy(28,14);
	printf("Press Enter to Start Game.");
	getch();
	detectgraph(&gdriver, &gmode);
	initgraph(&gdriver,&gmode,"P:\\TC\\BGI");
	x=getmaxx()/2;
	y=getmaxy()/2;
	setbkcolor(YELLOW);
	setcolor(BLUE);
	settextjustify(CENTER_TEXT, CENTER_TEXT);
	settextstyle(TRIPLEX_FONT, HORIZ_DIR, 10);
	cleardevice();
	sprintf(msg,"��KBC��");
	outtextxy(x,y,msg);
	delay(1200);
	cleardevice();
	closegraph();
}

void millionaire()
{
	int i,j,x,y;
	int gdriver , gmode;
	char msg[30];
	clrscr();
	detectgraph(&gdriver, &gmode);
	initgraph(&gdriver, &gmode, "P:\\TC\\BGI");
	settextjustify(CENTER_TEXT, CENTER_TEXT);
	settextstyle(SANS_SERIF_FONT,HORIZ_DIR,5);
	x=getmaxx()/2;
	y=getmaxy()/2;
	cleardevice();
	setbkcolor(WHITE);
	setcolor(MAGENTA);
	sprintf(msg,"--M:I:L:L:I:O:N:A:I:R:E--  ");
	outtextxy(x,y,msg);
	delay(1200);
	cleardevice();
	closegraph();
}