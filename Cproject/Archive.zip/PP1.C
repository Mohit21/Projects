#include<graphics.h>
#include<stdio.h>
#include<conio.h>
#include<dos.h>
#include<stdlib.h>
void header();
void first();
//PERSONAL INFO
void display();
void personal();
//----------------------------------------------------------------
struct stu
{
	char name[20];
	char fname[20];
	char mname[20];
	char address[50];
	char course[5];
	char smail[40];
	char pmail[40];
	char dob[15];
	long long int mob;
	long long int enr;
	int sem;
};
struct stu s;
//----------------------------------------------------------------------
//ACADEMIC INFO
//---------------------------------------------------------------------------
//ATTENDANCE
struct time_t
{
char sub[50];
char day[10];
};
//TIME TABLE
struct attend
{
char sub[15];
float ptt,pt,pl,pp;
};
void academic();
//----------------------------------------------------------------------------
void header()
{
printf("\t\t\t\tINFO-KIOSK");
printf("\n********************************************************************************");
	delay(2000);
	printf("\n\t\tJAYPEE INSTITUTE OF INFORMATION TECHNOLOGY");
	delay(2000);
	printf("\n\t\t\t     NOIDA,SECTOR-128");
	delay(2000);
	printf("\n--------------------------------------------------------------------------------");
	delay(1000);
	printf("\n\t\t\t\t\t\t\t\t\t NAME");
delay(2000);
}

void main()
{
int i,counter=0,flag=0;
char uid[25],pwd[25],s_uid[][25]={"11user1","12user2","13user3"};
char s_pwd[][25]={"Pwd1","Pwd2","Pwd3"},ch='a';/*dummy character in ch */
//------ Login
char ch2,ch3;
first();
textcolor(BLACK);
textbackground(GREEN);
clrscr();
printf("\t\t\t\t  INFO-KIOSK");
printf("\n********************************************************************************");
delay(2000);
printf("\n\t\tJAYPEE INSTITUTE OF INFORMATION TECHNOLOGY");

delay(2000);
printf("\n\t\t\t     NOIDA,SECTOR-128");
delay(2000);
printf("\n--------------------------------------------------------------------------------");
delay(1000);
printf("\n\n\n\t Enter the user id : ");
scanf("%s",uid);
printf("\n\n\t Enter the password : ");
i=0;
while(1)
{
	ch=getch();
	if(ch==13)
	break;
	else if(ch==8)
	{       if(i!=0)
		{
			printf("\b");
			printf("%c",32);
			printf("\b");
			i--;
			pwd[i]='\0';
		}
		else
		continue;
	}
	else
	{
	putchar('*');/* char - '*' will be printed instead of the character */
	pwd[i]=ch;
	i++;
	}
}
pwd[i]='\0';
for(i=0;i<=2;i++)
{
	if((stricmp(uid,s_uid[i]))==0 && (strcmp(pwd,s_pwd[i]))==0)
	{
		flag=1;
		break;
	}
}
if(flag) printf(" \n \n \t \t USER AUTHENTICATED ");
//-----------------------------------------------------
clrscr();
header();
printf("\n\t\t\t\t\t\t\t\t\t NAME");
delay(2000);
printf("\n\n\n\t\t1.PERSONAL INFO");
delay(1000);
printf("\n\n\t\t2.ACADEMIC INFO");
delay(1000);
printf("\n\n\t\t3.EXAM INFO");
delay(1000);
printf("\n\n\t\t4.SIGNOUT");
delay(1000);
printf("\nEnter Your Choice:");
do
{
fflush(stdin);
scanf("%c",&ch2);
 switch(ch2)
 {
 case '1':
	personal();
	  break;

 case '2':academic();
	  break;

 case '3':
	  break;

 case '4':printf("\nBREAKING!!");
	  exit(0);
	  break;
 default:printf("\n\tYou Entered Wrong Choice!!");
	printf("\nWant to Enter Again(Y/N):");
	scanf("%c",&ch3);
	if(ch3=='y'||ch3=='Y')
	{
	printf("\n\tAgain Enter Your Choice:");
	}
	break;
 }
 }
 while(ch3=='y'||ch3=='Y');

getch();
}


void academic()
{
FILE *fp,*fp1;
int d=7,i;
char ch,ch1;
struct time_t  t;
struct attend at;
textcolor(BLACK);
textbackground(GREEN);
clrscr();
fp=fopen("TimeTable.txt","r+");
fp1=fopen("Attend.txt","r+");
printf("\t\t\t\t\tINFO-KIOSK");
printf("\n********************************************************************************");
delay(2000);
//settextstyle(TIMESNEWROMAN,HORIZONTAL_LINE,1);
printf("\n\t\tJAYPEE INSTITUTE OF INFORMATION TECHNOLOGY");
delay(2000);
printf("\n\t\t\t     NOIDA,SECTOR-128");
delay(2000);
printf("\n--------------------------------------------------------------------------------");
delay(1000);
printf("\n\t\t\t\t\t\t\t\t\t NAME");
delay(2000);
printf("\n\n\n\t\t1.TIME TABLE");
delay(1000);
printf("\n\n\n\t\t2.ATTENDENCE");
delay(1000);
printf("\n\n\n\t\t3.EXIT");
delay(1000);
printf("\n\n\nEnter your choice to proceed(1-3):");
fflush(stdin);
scanf("%c",&ch);
//Palce here a line with help and further instructions!
switch(ch)
{
case '1':
	clrscr();
	header();
	printf("\n\n\t\t1.ADD");                //change
	printf("\n\t\t2.VIEW");                   //   change
	printf("\nEnter ur choice(1-2):");
	fflush(stdin);
	scanf("%c",&ch1);
	switch(ch1)
	{
case '1':clrscr();
	 header();
	 fseek(fp,0,SEEK_END);//TO APPEND THE FILE
	i=1;
	while(d>1)                                 //for 6 days
	{
	printf("\n\t\tEnter day%d:\t",i);
	fflush(stdin);
	gets(t.day);
	printf("\nEnter subject :");
	fflush(stdin);
	gets(t.sub);
	fprintf(fp,"%s\t%s\n",t.day,t.sub);
	d--;
	i++;
	}
	d=6;
	break;

case '2':

	clrscr();
	header();
	fseek(fp,0,SEEK_SET);
       //rewind(fp);
	delay(1000);
	printf("\n\n\t\tThe time table is as follows....");
	delay(5000);
	printf("\n\n\t\t9-10\t10-11\t11-12\t12-13\t13-14\t14-15\t15-16\t16-17\n");
	while(fscanf(fp,"\n%s %s",t.day,t.sub)!=EOF)
	{
	 printf("%s\t\t%s",t.day,t.sub);
	}
	break;

default:printf("Wrong choice!!");
	break;
	}
	break;
case '2':
	clrscr();
	header();
	printf("\n\n\t\t1.ADD");                        // change
	printf("\n\t\t2.VIEW");                          //   change
	printf("\nEnter ur choice(1-2):");
	fflush(stdin);
	scanf("%c",&ch1);
	switch(ch1)
	{
case '1':
	clrscr();
	header();
	fseek(fp1,0,SEEK_END);                    //TO APPEND THE FILE
	i=1;
	d=8;
	while(d>=1)                                 //for 6 days
	{
	printf("\n\t\tEnter subject%d:",i);
	fflush(stdin);
	gets(at.sub);
	if(strlen(at.sub)>8)
	{
	printf("\nEnter the Practical Lab Attendance:");
	fflush(stdin);
	scanf("%f",&at.pp);
	}
	else
	{
	printf("\nEnter total Percentage Attendance:");               //func to calculate the %
	fflush(stdin);
	scanf("%f",&at.ptt);
	printf("\nEnter the percentage attendance for Lecture:");
	fflush(stdin);
	scanf("%f",&at.pl);
	printf("\nEnter the percentage attendance for Tutorial:");
	fflush(stdin);
	scanf("%f",&at.pt);
	}
	fprintf(fp1,"%s\t\t%0.2f\t\t%0.2f\t\t%0.2f\t\t%0.2f\n",at.sub,at.ptt,at.pl,at.pl,at.pp);
	d--;
	i++;
	}

	break;
case '2': clrscr();
	header();
	fseek(fp1,0,SEEK_SET);
	//rewind(fp1);
	delay(1000);
	printf("\n\n\t\tThe attendence is as follows.....");
	delay(5000);
	printf("\n\nSUBJECT    LECTURE+TUTORIAL\tLECTURE \tTUTORIAL \tPRACTICAL\n\n");
	while(fscanf(fp1,"%s%f%f%f%f",at.sub,&at.ptt,&at.pl,&at.pt,&at.pp)!=EOF)
	{
	 if(strlen(at.sub)>8)
	 {
	 printf("%s \t\t\t\t\t\t\t%.2f",at.sub,at.pp);
	 printf("\n");
	 }
	 else
	 {
	 printf("%s\t\t%.2f\t\t%.2f\t\t%.2f",at.sub,at.ptt,at.pl,at.pt,at.pp);
	 printf("\n");
	 }
	}
	break;

default:printf("Wrong choice!!");
	break;
	}

	break;

case '3':printf("\n!!BREAKING!!");
	 break;
default:printf("\nWrong choice entered");
	break;

}                             //complete switch
fclose(fp);
fclose(fp1);

getch();
}


void first()
{

textcolor(BLACK);
textbackground(CYAN);
clrscr();
printf("\n\n********************************************************************************");
delay(1000);
printf("\n\t\tJAYPEE INSTITUTE OF INFORMATION TECHNOLOGY");
delay(1000);
printf("\n\t\t\t     NOIDA,SECTOR-128");
delay(1000);
printf("\n\n--------------------------------------------------------------------------------");
delay(2000);
printf("\n\n\t\t\t   DATA STRUCTURES PROJECT");
delay(1000);
printf("\n\n\t\t\t\t   INFO-KIOSK");
delay(1000);
printf("\n\n\t\tGROUP MEMEBERS:");
delay(1001);
printf("\n\n\t\t\t1.MOHIT KUMRA-9913103538");
delay(1001);
printf("\n\n\t\t\t2.ASTHA GUPTA-9913103637");
delay(1000);
printf("\n\n\t\t\t3.GOVIND SONI-9913103563");
delay(1000);
printf("\n\n\t\t\t4.ARNAV BHARDWAJ-9913103553");
delay(1000);
printf("\n\n\t\t\t5.MAHESH JAT-9913103649");
delay(2000);
}
/*PERSONAL*/
void display()
{
	int gd = DETECT, gm=0;
	initgraph(&gd,&gm,"C:\\TC\\BGI");
	line(125,25,125,450);
	line(525,25,125,25);
	line(525,450,525,25);
	line(525,63,125,63);
	line(125,450,525,450);
	line(300,25,300,450);
	line(525,101,125,101);
	line(525,139,125,139);
	line(525,177,125,177);
	line(525,223,125,223);
	line(525,261,125,261);
	line(525,299,125,299);
	line(525,337,125,337);
	line(525,337,125,337);
	line(525,375,125,375);
	line(525,413,125,413);
	line(525,451,125,451);
	gotoxy(25,3);
	printf("NAME");
	gotoxy(21,6);
	printf("FATHER'S NAME");
	gotoxy(21,8);
	printf("MOTHER'S NAME");
	gotoxy(20,10);
	printf("DATE OF BIRTH");
	gotoxy(24,13);
	printf("ADDRESS");
	gotoxy(21,16);
	printf("MOBILE NUMBER");
	gotoxy(21,18);
	printf("STUDENT'S EMAIL");
	gotoxy(21,20);
	printf("PARENT'S EMAIL");
	gotoxy(21,23);
	printf("ENROLLMENT NO.");
	gotoxy(21,25);
	printf("COURSE");
	gotoxy(21,26);
	printf("\n\n\n\t\t     SEMESTER");
       //	closegraph();
	getch();
	closegraph();
}
void personal()
{        	char ch,add,name[20];
	int i;
	long int recsize;
		FILE *fp;


	clrscr();
	 header();


	fp=fopen("Personal Info.txt","w");
	{
		if(fp==NULL)
		{
			printf("File Cannot Open:");
			exit(0);
		}
		recsize=sizeof(s);
		while(ch!='4')
		{
			clrscr();
			gotoxy(30,5);
			printf("Personal Info");
			gotoxy(30,10);
			printf("1. Add Records:");
			gotoxy(30,12);
			printf("2. List Records:");
			gotoxy(30,14);
			printf("3. Modify Records:");
			gotoxy(30,16);
			printf("4. Home:");
			gotoxy(30,18);
			printf("Enter Your Choice:");
			scanf("\t%c",&ch);
			switch(ch)
			{
				case '1':
				fseek(fp,0,SEEK_END);
				do
				{
					printf("\nEnter Name:");
					fflush(stdin);
					gets(s.name);
					printf("Enter Father's Name:");
					gets(s.fname);
					printf("Enter  Mother's Name:");
					gets(s.mname);
					printf("Enter Date Of Birth(dd/mm/yyyy):");
					gets(s.dob);
					printf("Enter Address:");
					gets(s.address);
					printf("Enter Mobile Number:");
					scanf("%lld",&s.mob);
					printf("Enter Student's Email:");
					fflush(stdin);
					gets(s.smail);
					printf("Enter Parent's Email:");
					gets(s.smail);
					printf("Enter Enrollment Number:");
					scanf("%lld",&s.enr);
					printf("Enter Course:");
					scanf("%s",s.course);
					printf("Enter Semester:");
					scanf("%d",&s.sem);
					fwrite(&s,recsize,1,fp);
					printf("\nRecord Added");
					printf("Add Another Record(y/n):");
					fflush(stdin);
					scanf("\t%c",&add);
					}while(add=='y');
					break;

				case '2':
			       /*	rewind(fp);
				while(fread(&s,1,recsize,fp)==1)
				{
					printf("\n%s%d%s",s.name,s.enr,s.course);
				}    */
				display();
				  break;
				case '3':
				add='y';
				while(add=='y')
				{
					printf("Enter Name Of The Student:");
					fflush(stdin);
					gets(name);
					rewind(fp);
					while(fread(&s,recsize,1,fp)==1)
					{
						if(strcmp(s.name,name)==0)
						{
							printf("Enter New Name,Date Of Birth,Mobile Number,Address And Email:");
							scanf("%s%s%lld%s%s",s.name,s.dob,&s.mob,s.address,s.smail);
							fseek(fp,-recsize,SEEK_CUR);
							fwrite(&s,recsize,1,fp);
							break;
						}
					}
					printf("Do You Want to Modify Another:");
					scanf("\t%c",&add);
				}
				case '4':
				fclose(fp);
				exit(0);
				default:
				exit(0);
			}
		}

	}
 }